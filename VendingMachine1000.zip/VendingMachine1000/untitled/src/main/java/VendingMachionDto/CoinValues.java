package VendingMachionDto;

public enum CoinValues {
    QUARTERS, DIMES, NICKLES, PENNIES
}
