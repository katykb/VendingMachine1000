package VendingMachineController;

import UserInputOutput.VendingMachineView;
import VendingMachineDao.VendingMachinePersistenceException;
import VendingMachineService.VendingMachineInsufficientFundsException;
import VendingMachineService.VendingMachineNoItemInventoryException;
import VendingMachineService.VendingMachineServiceIF;
import VendingMachionDto.Item;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class VendingMachineController {
    private VendingMachineView view;
    public VendingMachineServiceIF service;
    String input;

    Map<String, Item> showListOfItemsToBuy = new HashMap<>();

    public VendingMachineController(VendingMachineView view, VendingMachineServiceIF service) {
        this.view = view;
        this.service = service;
    }

    public void run() throws VendingMachinePersistenceException {

        BigDecimal moneyDeposited = new BigDecimal("0");
        boolean keepGoing = true;
        int menuSelection = 0;

        try {
            while (keepGoing) {

                view.displayVendingMachineWelcome();
                menuSelection = view.displayMainMenuAndGetSelection();

                switch (menuSelection) {
                    case 1:
                        viewAndBuyItems();
                        break;

                    case 2:
                      addFunds(moneyDeposited);
                      break;

                    case 3:
                        keepGoing = false;
                    default:
                        unknownCommand();
                }
            }
            view.displayFinalMessage();
        } catch (VendingMachinePersistenceException e) {
            view.displayErrorMessage(e.getMessage());
        }
    }

    public BigDecimal addFunds(BigDecimal balance){
        Scanner scanner = new Scanner(System.in);
        BigDecimal moneyAdded;
        moneyAdded = BigDecimal.valueOf(scanner.nextInt());
        return moneyAdded;
    }


    private void viewAndBuyItems() throws VendingMachinePersistenceException {
        BigDecimal userFunds = view.promptUserMoneyInput();
        view.displayUserMoneyInput(userFunds);

        List<Item> itemList = service.listAllItemsToBuy();
        view.displayItemList(itemList);

        String userItemSelection = view.displayUserChoiceOfItem(input);
        System.out.println("You have chosen: " + userItemSelection);
        Item itemUserSelected = showListOfItemsToBuy.get(userItemSelection);

//        try {
//            service.loadItemsInStock();
//        } catch (VendingMachinePersistenceException e) {
//            throw new RuntimeException(e);
//        }




        //System.out.println(itemUserSelected + "cost: " + itemUserSelected.getItemPrice());

    }

//        Scanner scanner = new Scanner(System.in);
//        while (true) {
//            view.promptUserItemChoice();
//            scanner.nextLine();
//            try {
//                String myItem = service.getChosenItem(itemId);
//                view.displayUserChoiceOfItem(item);
//
//            } catch (VendingMachineNoItemInventoryException exception) {
//            }
//        }
//    }

   public boolean didUserPutSufficientFundsIn(BigDecimal userAmount, Item item) {
        try {
            service.checkSufficientMoneyToBuyItem(userAmount, String.valueOf(item));
            return true;
        } catch (VendingMachineInsufficientFundsException ex) {
            view.displayErrorMessage("Not enough money to buy!");
            view.displayUserMoneyInput(userAmount);
            return false;
        }
    }

    public void displayChangeReturnedToUser(BigDecimal amount, Item item) {
        BigDecimal change = service.calculateChange(amount, item);
        view.displayChangeReturnedToCustomer(change, String.valueOf(item));
    }

//        public boolean toExitVendingMachine ( boolean isEnoughMoney){
//            if (isEnoughMoney) {
//                return false;
//            } else {
//                return view.toExit(true);
//            }
//        }

//        void displayErrorMessage (String message){
//            view.displayErrorMessage(message);
//        }

    public void updateSoldItem(Item item) throws VendingMachinePersistenceException {
        try {
            service.updateItemSale(String.valueOf(item));
        } catch (VendingMachineNoItemInventoryException ex) {
            throw new VendingMachinePersistenceException(ex.getMessage());
        }
    }
//        void saveItemList () throws VendingMachinePersistenceException {
//            try {
//                service.saveItemList();
//            } catch (VendingMachinePersistenceException e) {
//                throw new RuntimeException(e);
//            }
//        }

    private void unknownCommand() {
        view.displayUnknownCommandBanner();
    }

    private void exitMessage() {
        view.displayExitBanner();
    }
}



